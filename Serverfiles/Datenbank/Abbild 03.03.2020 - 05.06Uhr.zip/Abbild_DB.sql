-- MySQL dump 10.15  Distrib 10.0.38-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: 10.35.47.221    Database: k95631_musik
-- ------------------------------------------------------
-- Server version	5.7.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `k95631_musik`
--


--
-- Table structure for table `Album`
--

DROP TABLE IF EXISTS `Album`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Album` (
  `AlbumID` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(30) NOT NULL,
  `Trackzahl` tinyint(4) DEFAULT NULL,
  `Veröffentlichungsjahr` year(4) DEFAULT NULL,
  PRIMARY KEY (`AlbumID`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Album`
--

LOCK TABLES `Album` WRITE;
/*!40000 ALTER TABLE `Album` DISABLE KEYS */;
INSERT INTO `Album` VALUES (8,'Hardstyle-Mix',100,2020),(9,'House',100,2020),(10,'Rockiges',100,2020);
/*!40000 ALTER TABLE `Album` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Albumtracks`
--

DROP TABLE IF EXISTS `Albumtracks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Albumtracks` (
  `TrackID` int(11) NOT NULL,
  `AlbumID` int(11) NOT NULL,
  PRIMARY KEY (`TrackID`,`AlbumID`),
  KEY `fk_Track_has_Album_Album1_idx` (`AlbumID`),
  KEY `fk_Track_has_Album_Track1_idx` (`TrackID`),
  CONSTRAINT `fk_Track_has_Album_Album1` FOREIGN KEY (`AlbumID`) REFERENCES `Album` (`AlbumID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_Track_has_Album_Track1` FOREIGN KEY (`TrackID`) REFERENCES `Track` (`TrackID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Albumtracks`
--

LOCK TABLES `Albumtracks` WRITE;
/*!40000 ALTER TABLE `Albumtracks` DISABLE KEYS */;
INSERT INTO `Albumtracks` VALUES (1,8),(2,8),(3,8),(4,8),(6,8),(7,8),(5,9),(10,9),(11,9),(12,9),(13,9),(8,10),(9,10),(14,10),(16,10),(17,10),(18,10),(19,10);
/*!40000 ALTER TABLE `Albumtracks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Genre`
--

DROP TABLE IF EXISTS `Genre`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Genre` (
  `GenreID` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(20) NOT NULL,
  PRIMARY KEY (`GenreID`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Genre`
--

LOCK TABLES `Genre` WRITE;
/*!40000 ALTER TABLE `Genre` DISABLE KEYS */;
INSERT INTO `Genre` VALUES (1,'Early Hardstyle'),(2,'Euphoric Hardstyle'),(3,'Rawstyle'),(4,'Christian Rock'),(5,'Alternative Rock'),(6,'Rap'),(7,'Future House'),(8,'Deep House'),(9,'Future House'),(10,'Tropical House'),(11,'Big-Room House'),(12,'Psytrance'),(13,'Electro-House');
/*!40000 ALTER TABLE `Genre` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Genrezuordnung`
--

DROP TABLE IF EXISTS `Genrezuordnung`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Genrezuordnung` (
  `TrackID` int(11) NOT NULL,
  `GenreID` int(11) NOT NULL,
  PRIMARY KEY (`TrackID`,`GenreID`),
  KEY `fk_Track_has_Genre_Genre1_idx` (`GenreID`),
  KEY `fk_Track_has_Genre_Track1_idx` (`TrackID`),
  CONSTRAINT `fk_Track_has_Genre_Genre1` FOREIGN KEY (`GenreID`) REFERENCES `Genre` (`GenreID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_Track_has_Genre_Track1` FOREIGN KEY (`TrackID`) REFERENCES `Track` (`TrackID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Genrezuordnung`
--

LOCK TABLES `Genrezuordnung` WRITE;
/*!40000 ALTER TABLE `Genrezuordnung` DISABLE KEYS */;
INSERT INTO `Genrezuordnung` VALUES (3,1),(6,1),(7,1),(1,2),(2,2),(4,2),(8,4),(18,4),(19,4),(8,5),(9,5),(16,5),(17,5),(14,6),(15,6),(10,8),(12,8),(13,8),(11,9),(5,10),(8,11);
/*!40000 ALTER TABLE `Genrezuordnung` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Kuenstler`
--

DROP TABLE IF EXISTS `Kuenstler`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Kuenstler` (
  `KünstlerID` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(20) DEFAULT NULL,
  `Genre` int(11) NOT NULL,
  PRIMARY KEY (`KünstlerID`),
  KEY `fk_Künstler_Typ_idx` (`Genre`),
  CONSTRAINT `fk_Künstler_Typ` FOREIGN KEY (`Genre`) REFERENCES `Typ` (`TypID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Kuenstler`
--

LOCK TABLES `Kuenstler` WRITE;
/*!40000 ALTER TABLE `Kuenstler` DISABLE KEYS */;
INSERT INTO `Kuenstler` VALUES (17,'Coone',1),(18,'Wasted Penguinz',4),(19,'Twenty One Pilots',2),(20,'Robin Schulz',1),(21,'Brennan Heart',1),(22,'KSHMR',1),(23,'Sam Feldt',1),(24,'Eminem',1),(25,'Fall Out Boy',2),(26,'Skillet',2),(31,'test',1),(32,'etest',1),(33,'etest',1);
/*!40000 ALTER TABLE `Kuenstler` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Track`
--

DROP TABLE IF EXISTS `Track`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Track` (
  `TrackID` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(20) NOT NULL,
  `Laenge` time DEFAULT NULL,
  `Veröffentlichungsjahr` year(4) DEFAULT NULL,
  PRIMARY KEY (`TrackID`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Track`
--

LOCK TABLES `Track` WRITE;
/*!40000 ALTER TABLE `Track` DISABLE KEYS */;
INSERT INTO `Track` VALUES (1,'Faye','03:33:00',2016),(2,'Fight for something','03:19:00',2019),(3,'Life begins','03:27:00',2019),(4,'In Your Eyes','03:28:00',2020),(5,'Sugar','03:39:00',2015),(6,'Magic','04:00:00',2016),(7,'Clarity','04:24:00',2016),(8,'Chlorine','05:24:00',2018),(9,'Stressed Out','03:22:00',2015),(10,'No Regrets','03:04:00',2019),(11,'Power','03:29:00',2017),(12,'Winter Wonderland','03:04:00',2019),(13,'Gold','03:03:00',2019),(14,'Stan','06:44:00',2000),(15,'Darkness','05:37:00',2020),(16,'The Phoenix','04:05:00',2013),(17,'Dear Future Self','02:51:00',2009),(18,'Lions','03:25:00',2016),(19,'Out of Hell','03:34:00',2016);
/*!40000 ALTER TABLE `Track` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Trackinterpret`
--

DROP TABLE IF EXISTS `Trackinterpret`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Trackinterpret` (
  `TrackID` int(11) NOT NULL,
  `KünstlerID` int(11) NOT NULL,
  PRIMARY KEY (`TrackID`,`KünstlerID`),
  KEY `fk_Track_has_Künstler_Künstler1_idx` (`KünstlerID`),
  KEY `fk_Track_has_Künstler_Track1_idx` (`TrackID`),
  CONSTRAINT `fk_Track_has_Künstler_Künstler1` FOREIGN KEY (`KünstlerID`) REFERENCES `Kuenstler` (`KünstlerID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `fk_Track_has_Künstler_Track1` FOREIGN KEY (`TrackID`) REFERENCES `Track` (`TrackID`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Trackinterpret`
--

LOCK TABLES `Trackinterpret` WRITE;
/*!40000 ALTER TABLE `Trackinterpret` DISABLE KEYS */;
INSERT INTO `Trackinterpret` VALUES (1,17),(2,17),(6,18),(7,18),(8,19),(9,19),(5,20),(2,21),(3,21),(4,21),(10,22),(11,22),(12,23),(13,23),(14,24),(15,24),(16,25),(17,25),(18,26),(19,26);
/*!40000 ALTER TABLE `Trackinterpret` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Typ`
--

DROP TABLE IF EXISTS `Typ`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Typ` (
  `TypID` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(45) NOT NULL,
  PRIMARY KEY (`TypID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Typ`
--

LOCK TABLES `Typ` WRITE;
/*!40000 ALTER TABLE `Typ` DISABLE KEYS */;
INSERT INTO `Typ` VALUES (1,'Solokünstler'),(2,'Band'),(3,'Gruppe'),(4,'Duo'),(5,'Orchester');
/*!40000 ALTER TABLE `Typ` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-03  5:06:25

